package org.example;

abstract class Manejador {
    protected Manejador
            siguienteManejador;
    public void
    establecerSiguienteManejador(Manejador siguienteManejador) {
        this.siguienteManejador = siguienteManejador;
    }

    public abstract void manejarPeticion(String Peticion);
}

class ManejadorConcretoA extends Manejador {
    public void manejarPeticion(String peticion){
        if (peticion.equals("A")) {
            System.out.println("Manejador A proceso la información.");
        }
        else if (siguienteManejador != null) {
            siguienteManejador.manejarPeticion(peticion);
        }
    }
}

class ManejadorConcretoB extends Manejador {
    public void manejarPeticion(String peticion) {
        if(peticion.equals("B")) {
            System.out.println("Manejador B procesó la información.");
        }
        else if(siguienteManejador != null) {
            siguienteManejador.manejarPeticion(peticion);
        }
    }
}
class ManejadorConcretoC extends Manejador {
    public void manejarPeticion(String peticion) {
        if(peticion.equals("C")) {
            System.out.println("Manejador C procesó la información.");
        }
        else if(siguienteManejador != null) {
            siguienteManejador.manejarPeticion(peticion);
        }
    }
}
public class DemoCadenaDeResponsabilidad{
    public static void main(String[] args) {
        Manejador manejadorA = new ManejadorConcretoA();
        Manejador manejadorB = new ManejadorConcretoB();
        Manejador manejadorC = new ManejadorConcretoC();

        manejadorA.establecerSiguienteManejador(manejadorB);
        manejadorB.establecerSiguienteManejador(manejadorC);

        manejadorA.manejarPeticion("A");
        manejadorA.manejarPeticion("B");
        manejadorA.manejarPeticion("C");
        manejadorA.manejarPeticion("D");
    }

}
