abstract class CarreraCoche {

    // Método plantilla que define el flujo general de la carrera
    public final void realizarCarrera() {
        iniciarMotor();     // Iniciar el motor del coche
        for (int i = 0; i < 3; i++) {  // Simula 3 vueltas en la pista
            System.out.println("\n--- Vuelta " + (i + 1) + " ---");
            acelerar();     // Acelerar el coche
            tomarCurvas();  // Tomar las curvas
            frenar();       // Frenar el coche
        }
        cruzarMeta();      // Cruza la meta al finalizar la carrera
    }

    // Métodos abstractos que las subclases deben implementar
    protected abstract void acelerar();     // Método para acelerar el coche
    protected abstract void tomarCurvas();  // Método para tomar curvas
    protected abstract void frenar();       // Método para frenar el coche

    // Método concreto, común para todos los tipos de coches
    private void iniciarMotor() {
        System.out.println("El motor del coche ha sido iniciado.");
    }

    // Método concreto, común para todos los tipos de coches
    private void cruzarMeta() {
        System.out.println("¡El coche ha cruzado la meta!");
    }
}

