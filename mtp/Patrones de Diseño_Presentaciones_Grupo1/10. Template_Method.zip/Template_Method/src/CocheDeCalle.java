class CocheDeCalle extends CarreraCoche {

    @Override
    protected void acelerar() {
        System.out.println("El coche de calle acelera lentamente...");
        for (int i = 0; i < 4; i++) {
            System.out.println("Velocidad actual: " + (i * 10) + " km/h");
        }
        System.out.println("El coche de calle ha alcanzado su velocidad máxima.");
    }

    @Override
    protected void tomarCurvas() {
        System.out.println("El coche de calle toma las curvas con precaución.");
        for (int i = 0; i < 2; i++) {
            System.out.println("Curva " + (i + 1) + " tomada a baja velocidad.");
        }
    }

    @Override
    protected void frenar() {
        System.out.println("El coche de calle frena suavemente...");
        for (int i = 3; i > 0; i--) {
            System.out.println("Velocidad actual: " + (i * 10) + " km/h");
        }
        System.out.println("El coche de calle ha frenado completamente.");
    }
}

