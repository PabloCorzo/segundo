class CocheDeCarreras extends CarreraCoche {

    @Override
    protected void acelerar() {
        System.out.println("El coche de carreras está acelerando...");
        int velocidad = 0;
        while (velocidad < 200) {
            velocidad += 50;
            System.out.println("Velocidad actual: " + velocidad + " km/h");
        }
        System.out.println("El coche de carreras ha alcanzado su velocidad máxima.");
    }

    @Override
    protected void tomarCurvas() {
        System.out.println("El coche de carreras toma la curva a gran velocidad.");
        for (int i = 0; i < 3; i++) {
            System.out.println("Curva " + (i + 1) + " tomada a " + (150 - i * 20) + " km/h.");
        }
    }

    @Override
    protected void frenar() {
        System.out.println("El coche de carreras está frenando...");
        int velocidad = 200;
        while (velocidad > 0) {
            velocidad -= 50;
            System.out.println("Velocidad actual: " + velocidad + " km/h");
        }
        System.out.println("El coche de carreras ha frenado completamente.");
    }
}