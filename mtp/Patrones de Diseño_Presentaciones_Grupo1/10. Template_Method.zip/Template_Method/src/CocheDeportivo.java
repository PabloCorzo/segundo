class CocheDeportivo extends CarreraCoche {

    @Override
    protected void acelerar() {
        System.out.println("El coche deportivo está acelerando...");
        for (int i = 0; i < 5; i++) {
            System.out.println("Velocidad actual: " + (i * 20) + " km/h");
        }
        System.out.println("El coche deportivo ha alcanzado su velocidad máxima.");
    }

    @Override
    protected void tomarCurvas() {
        System.out.println("El coche deportivo toma la curva con precisión.");
        for (int i = 0; i < 3; i++) {
            System.out.println("Curva " + (i + 1) + " completada.");
        }
    }

    @Override
    protected void frenar() {
        System.out.println("El coche deportivo está frenando...");
        for (int i = 5; i > 0; i--) {
            System.out.println("Velocidad actual: " + (i * 20) + " km/h");
        }
        System.out.println("El coche deportivo ha frenado completamente.");
    }
}
