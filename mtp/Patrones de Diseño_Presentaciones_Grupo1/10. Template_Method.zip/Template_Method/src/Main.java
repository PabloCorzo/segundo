public class Main {
    public static void main(String[] args) {
        // Crear instancias de los diferentes tipos de coches
        CarreraCoche cocheDeportivo = new CocheDeportivo();
        CarreraCoche cocheDeCarreras = new CocheDeCarreras();
        CarreraCoche cocheDeCalle = new CocheDeCalle();

        // Realizar carreras con diferentes coches
        System.out.println("Carrera con coche deportivo:");
        cocheDeportivo.realizarCarrera();

        System.out.println("\nCarrera con coche de carreras:");
        cocheDeCarreras.realizarCarrera();

        System.out.println("\nCarrera con coche de calle:");
        cocheDeCalle.realizarCarrera();
    }
}
