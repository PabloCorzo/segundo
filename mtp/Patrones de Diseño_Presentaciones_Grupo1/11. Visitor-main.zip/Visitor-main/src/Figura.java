public interface Figura {
    public void aceptar(Visitor visitor);
}
