public interface Visitor {
    public void visitar(Circulo circulo);
    public void visitar(Cuadrado cuadrado);
    public void visitar(Triangulo triangulo);
}
