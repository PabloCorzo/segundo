//comando concreto para cambiar canal de TV
public class CambiarCanal implements Command {
    private TV tv;

    public CambiarCanal(TV tv) {
        this.tv = tv;
    }

    @Override
    public void ejecutar() {
        tv.cambiarCanal();
    }
}