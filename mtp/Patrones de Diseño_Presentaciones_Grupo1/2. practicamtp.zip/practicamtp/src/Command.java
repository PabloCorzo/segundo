
//comando interfaz
public interface Command {
    void ejecutar();
}
