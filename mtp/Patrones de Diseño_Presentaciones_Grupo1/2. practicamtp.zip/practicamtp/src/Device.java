// interfaz de la Receiver
public interface Device {
    void encender();
    void apagar();

}
