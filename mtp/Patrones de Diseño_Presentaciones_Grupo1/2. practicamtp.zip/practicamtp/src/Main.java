public class Main {
    public static void main(String[] args) {
       //crear dispositivos
        TV tv = new TV();
        Stereo stereo = new Stereo();

        //crear objetos commandos
        Command OnTVCommand = new OnCommand(tv);
        Command OffTVCommand = new OffCommand(tv);
        Command volumenstereo = new ModificarVolumen(stereo);
        Command cambiarcanal = new CambiarCanal(tv);

        //crear control remoto
        controlremoto mando = new controlremoto();

        //setters y ejecutar comandos
        mando.setCommand(OnTVCommand);
        mando.pressButton();

        mando.setCommand(volumenstereo);
        mando.pressButton();

        mando.setCommand(cambiarcanal);
        mando.pressButton();

        mando.setCommand(OffTVCommand);
        mando.pressButton();


    }
}