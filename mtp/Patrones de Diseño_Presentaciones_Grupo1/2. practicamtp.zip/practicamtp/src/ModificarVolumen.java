//comando concreto para modificar el volumen
public class ModificarVolumen implements Command {
    private Stereo stereo;

    public ModificarVolumen(Stereo stereo) {
        this.stereo = stereo;
    }

    @Override
    public void ejecutar() {
        stereo.ajustarVolumen();
    }
}