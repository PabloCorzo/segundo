//comando concreto para apagar el dipositivo
public class OffCommand implements Command {
    private Device device;

    public OffCommand(Device device) {
        this.device = device;
    }

    @Override
    public void ejecutar() {
        device.apagar();
    }
}
