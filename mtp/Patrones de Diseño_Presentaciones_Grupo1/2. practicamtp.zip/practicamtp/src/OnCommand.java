//comando concreto para encender el dipositivo

public class OnCommand implements Command {
    private Device device;

    public OnCommand(Device device) {
        this.device = device;
    }

    @Override
    public void ejecutar() {
        device.encender();
    }
}