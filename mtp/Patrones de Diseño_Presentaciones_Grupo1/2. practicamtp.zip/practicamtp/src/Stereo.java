//recividor concreto para una Stereo(poner sonido)
public class Stereo implements Device {
    @Override
    public void encender() {
        System.out.println("Stereo esta encendido");
    }

    @Override
    public void apagar() {
        System.out.println("Stereo esta apagado");
    }

    public void ajustarVolumen() {
        System.out.println("Volume ajustado");
    }
}