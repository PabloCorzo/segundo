//recividor concreto para una TV
public class TV implements Device {
    @Override
    public void encender() {
        System.out.println("TV esta encendida");
    }

    @Override
    public void apagar() {
        System.out.println("TV esta apagada");
    }

    public void cambiarCanal() {
        System.out.println("Canal cambiado");
    }
}