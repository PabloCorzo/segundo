package interpreter;
public interface Expression {
    public int interpret();
}