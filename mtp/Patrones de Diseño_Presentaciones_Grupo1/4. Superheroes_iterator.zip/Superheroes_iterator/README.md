# Superheroes_iterator

El iterador nos permite acceder a cada superhéroe de forma secuencial sin exponer cómo está implementada la colección (ya sea un array, lista, etc.), lo que es una de las principales ventajas del patrón




