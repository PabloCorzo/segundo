package src;

// Colección
public interface Aggregate {
    Iterator createIterator(); // Método para crear el iterador
}
