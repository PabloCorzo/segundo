package src;

// Iterator
public interface Iterator {
    boolean hasNext(); // Verifica si hay más superhéroes en la colección
    Object next();     // Devuelve el siguiente superhéroe en la colección
}