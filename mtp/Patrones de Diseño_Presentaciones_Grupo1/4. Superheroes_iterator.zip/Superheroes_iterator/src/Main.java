package src;

// Cliente
public class Main {
    public static void main(String[] args) {
        // Crear una colección de superhéroes
        SuperheroCollection marvelHeroes = new SuperheroCollection(5);

        // Añadir superhéroes a la colección
        marvelHeroes.addSuperhero(new Superhero("Spider-Man", "Sentido arácnido"));
        marvelHeroes.addSuperhero(new Superhero("Iron Man", "Armadura de alta tecnología"));
        marvelHeroes.addSuperhero(new Superhero("Thor", "Control del trueno"));
        marvelHeroes.addSuperhero(new Superhero("Hulk", "Fuerza sobrehumana"));
        marvelHeroes.addSuperhero(new Superhero("Doctor Strange", "Magia mística"));

        // Crear el iterador
        Iterator iterator = marvelHeroes.createIterator();

        // Recorrer la colección de superhéroes usando el iterador
        while (iterator.hasNext()) {
            Superhero hero = (Superhero) iterator.next();
            System.out.println(hero.getName() + " tiene el poder de: " + hero.getPower());
        }
    }
}