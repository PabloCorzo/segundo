package src;

public class Superhero {
    private String name;
    private String power;

    public Superhero(String name, String power) {
        this.name = name;
        this.power = power;
    }

    public String getName() {
        return name;
    }

    public String getPower() {
        return power;
    }
}









