package src;

//Coleccion concreta
public class SuperheroCollection implements Aggregate {
    private Superhero[] superheroes;
    private int index = 0;

    public SuperheroCollection(int size) {
        superheroes = new Superhero[size]; // Inicializamos la colección con un tamaño fijo
    }

    public void addSuperhero(Superhero superhero) {
        if (index < superheroes.length) {
            superheroes[index] = superhero;
            index++;
        }
    }

    @Override
    public Iterator createIterator() {
        return new SuperheroIterator(superheroes); // Retorna el iterador para esta colección
    }
}