package src;

// Concrete Iterator
public class SuperheroIterator implements Iterator {
    private Superhero[] superheroes;
    private int position = 0;

    public SuperheroIterator(Superhero[] superheroes) {
        this.superheroes = superheroes;
    }

    @Override
    public boolean hasNext() {
        return position < superheroes.length && superheroes[position] != null; // Verifica si hay más superhéroes
    }

    @Override
    public Superhero next() {
        return superheroes[position++]; // Devuelve el siguiente superhéroe y avanza la posición
    }
}
