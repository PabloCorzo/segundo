package SRC; 



public class ChurrosMachineMediator implements MachineMediator{
    
    private Heater heater;
    private WaterDispenser waterDispenser;
    private Mixer mixer;

    ChurrosMachineMediator(Heater h, WaterDispenser w, Mixer m){
        

        heater = h;
        waterDispenser = w;
        mixer = m;
    }

    @Override
    public void startMaquina(){
        System.out.println("Proceso de churro empezado");
        startTemperatura();
    }

    @Override
    public void startTemperatura() {
        heater.heatChurros(30);
    }

    @Override
    public void rellenarAgua() {
        waterDispenser.fillWithWater(150);
    }

    @Override
    public void mezclarIngredientes(){
        mixer.mixIngredients(300);
    }

    @Override
    public void apagar() {
        System.out.println("Apagado");
    }

    @Override
    public void startMaquina() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'startMachine'");
    }




}
