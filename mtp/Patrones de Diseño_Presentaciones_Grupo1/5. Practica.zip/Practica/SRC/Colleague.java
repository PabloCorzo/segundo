package SRC;


public interface Colleague{
    void setMediator(MachineMediator mediator);
}