package SRC;

public interface MachineMediator {
    void startMaquina();
    void startTemperatura();
    void rellenarAgua();
    void mezclarIngredientes();
    void apagar();
    
    
}
