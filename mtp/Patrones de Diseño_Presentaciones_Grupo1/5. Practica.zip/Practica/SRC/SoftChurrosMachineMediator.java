package SRC;


public class SoftChurrosMachineMediator implements MachineMediator{
    private Heater heater;
    private WaterDispenser waterDispenser;
    private Mixer mixer;

    SoftChurrosMachineMediator(Heater h, WaterDispenser w, Mixer m){
        

        heater = h;
        waterDispenser = w;
        mixer = m;
    }

    @Override
    public void startMaquina(){
        System.out.println("Proceso de porra empezado");
        startTemperatura();
    }

    @Override
    public void startTemperatura() {
        heater.heatChurros(20);
    }

    @Override
    public void rellenarAgua() {
        waterDispenser.fillWithWater(300);
    }

    @Override
    public void mezclarIngredientes(){
        mixer.mixIngredients(150);
    }

    @Override
    public void apagar() {
        System.out.println("Apagado");
    }
}   
