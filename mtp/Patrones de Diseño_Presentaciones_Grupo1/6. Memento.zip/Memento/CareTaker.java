import java.util.ArrayList;
import java.util.List;

// Clase CareTaker: Administra los Mementos para guardar y cargar el progreso del juego
class CareTaker {
    private List<Memento> guardarPuntos = new ArrayList<>(); // Lista de puntos de guardado (Mementos)

    // Agregar un nuevo punto de guardado a la lista
    public void addSavePoint(Memento memento) {
        guardarPuntos.add(memento);
    }

    // Obtener un punto de guardado específico de la lista
    public Memento getSavePoint(int index) {
        // Validación del índice para evitar errores
        if (index >= 0 && index < guardarPuntos.size()) {
            return guardarPuntos.get(index);
        } else {
            System.out.println("El punto de guardado no existe.");
            return null;
        }
    }
}
