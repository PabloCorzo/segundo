//La clase memento almacena el estado del juego
public class Memento {

    private int nivel;  //Nivel del jugador en el momento del guardado
    private int puntaje; //Puntaje del jugador en el momento del guardado

    //Constructor de Menemento que guarda el nivel y puntaje actual del jugador
    public Memento(int nivel, int puntaje) {
        this.nivel= nivel;
        this.puntaje= puntaje;
    }


    //Getter para obtener el nivel del guardado en el Memento
    public int getNivel() {
        return nivel;
    }

    //Getter para obtener el puntaje del guardado en el Memento
    public int getPuntaje() {
        return puntaje;
    }
}