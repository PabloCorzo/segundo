// Clase principal para demostrar el uso del patrón Memento en el juego
public class MementoGameDemo {
    public static void main(String[] args) {
         // Crear el juego (Originator) y el historial de guardado (CareTaker)
         Originator juego = new Originator();
         CareTaker historial = new CareTaker();

         // Simular el avance del juego y guardar estados
         System.out.println("Simulando el progreso deljuego...");
         juego.setGame(1, 1000);
         historial.addSavePoint(juego.guardar());  // Guardar nivel 1, puntaje 1000
         System.out.println("Estado guardado: Nivel 1, Puntaje 1000");

         juego.setGame(2, 2000);
         historial.addSavePoint(juego.guardar());  // Guardar nivel 2, puntaje 2000
         System.out.println("Estado guardado: Nivel 2, Puntaje 2000");

         juego.setGame(3, 3000);
         historial.addSavePoint(juego.guardar());  // Guardar nivel 3, puntaje 3000
         System.out.println("Estado guardado: Nivel 3, Puntaje 3000");

         // Restaurar directamente el segundo guardado (nivel 2)
         System.out.println("\n== Intentando restaurar el Nivel 2 ==");
         Memento savedGame = historial.getSavePoint(1); // Recuperar el segundo guardado

         // Verificar y restaurar el guardado
         if (savedGame != null) {
             System.out.println("Punto de guardado encontrado. Restaurando el estado...");
             juego.restaurar(savedGame);  // Restaurar al nivel y puntaje guardados
             System.out.println("Estado restaurado: Nivel " + savedGame.getNivel() + ", Puntaje " + savedGame.getPuntaje());
         } else {
             System.out.println("No se encontrado el nivel de guardado.");
         }
    }
}

