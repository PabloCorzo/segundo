// Clase Originator: Representa el estado actual del juego del jugador
class Originator {
    private int nivel; // Nivel actual del juego
    private int puntaje; // Puntaje actual del juego

    // Método para actualizar el estado actual del juego (nivel y puntaje)
    public void setGame(int nivel, int puntaje) {
        this.nivel = nivel;
        this.puntaje =  puntaje;
        System.out.println("Nivel: " + nivel + ", Puntaje: " + puntaje);
    }

    // Método para crear un Memento que guarde el estado actual del juego
    public Memento guardar() {
        return new Memento(nivel, puntaje);
    }

    // Método para restaurar el estado del juego desde un Memento
    public void restaurar(Memento memento) {
        this.nivel = memento.getNivel();
        this.puntaje= memento.getPuntaje();
    }
}
