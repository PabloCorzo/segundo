# MTP-State-rengelferreira-quintanovazques
Trabajo sobre Patrones de diseño
Patron de comportamiento State
