public class Iniciar implements State{

    private Maquina maquina;

    public void iniciarMaquina(){
        System.out.println("Iniciando máquina...");
        maquina.setState(new SeleccionProducto());
        System.out.println("Pulse (2) para teclear el producto");

    }
    public void teclearNumero(){
        System.out.println("Debe iniciar la máquina antes de pedir");
    }
    public void stock(){
        System.out.println("Debe iniciar la máquina antes de pedir");
    }
    public void pago(){
        System.out.println("Debe iniciar la máquina antes de pedir");
    }
    public void setMaquina(Maquina maquina){
        this.maquina = maquina;
    }

    
}