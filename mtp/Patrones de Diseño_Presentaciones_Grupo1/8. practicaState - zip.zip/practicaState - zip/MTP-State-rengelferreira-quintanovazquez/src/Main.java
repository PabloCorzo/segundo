import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Maquina maquina = new Maquina();
        
        Scanner lector = new Scanner(System.in);
            

        int opcion;

        System.out.println("1) Iniciar Máquina");
        System.out.println("2) Seleccionar Producto");
        System.out.println("3) Saber Disponibilidad");
        System.out.println("4) Pagar");
        System.out.println("5) Cerrar");

        do{

            opcion = lector.nextInt();

            switch (opcion) {
                case 1:
                    maquina.iniciarMaquina();
                    break;
                case 2:
                    maquina.teclearNumero();
                    break;
                case 3:
                    maquina.stock();
                    break;
                case 4:
                    maquina.pago();
                    break;
                case 5:
                    System.out.println("Cerrando...");
                    break;
                default:
                    System.out.println("Opcion no válida");
                    break;
            } 
        }while(opcion!=5);
        
    }
}