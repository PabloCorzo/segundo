public class Maquina {

    private State estado;

    public Maquina(){
        setState(new Iniciar());
    }

    public void setState(State estado)
    {
        this.estado = estado;
        this.estado.setMaquina(this);
    }

    public void iniciarMaquina(){
        this.estado.iniciarMaquina();
    }
    public void teclearNumero(){
        this.estado.teclearNumero();
    }
    public void stock(){
        this.estado.stock();
    }
    public void pago(){
        this.estado.pago();
    }
}