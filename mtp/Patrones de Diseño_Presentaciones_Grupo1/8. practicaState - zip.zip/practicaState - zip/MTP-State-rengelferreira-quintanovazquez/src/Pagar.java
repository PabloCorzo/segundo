public class Pagar implements State{

    private Maquina maquina;

    public void iniciarMaquina(){
        System.out.println("Máquina ya iniciada");
    }
    public void teclearNumero(){
        System.out.println("Ya seleccionó el producto, debe pagar");
    }
    public void stock(){
        System.out.println("Producto disponible, haga el pago");
    }
    public void pago(){
        System.out.println("Pagando...");
        System.out.println("Listo! Ya puede recoger su producto");
        maquina.setState(new Iniciar());
        System.out.println("Pulse (1) para volver a pedir");
    }
    public void setMaquina(Maquina maquina){
        this.maquina = maquina;
    }
}