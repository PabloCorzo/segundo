import java.util.*;
public class SeleccionProducto implements State {

    private Maquina maquina;
    Scanner numeroProducto = new Scanner(System.in);
    int producto;

    public void iniciarMaquina(){
        System.out.println("Máquina ya iniciada");
    }
    public void teclearNumero(){
        System.out.println("Teclee el número del producto que desea");
        producto =  numeroProducto.nextInt();
        maquina.setState(new StockProducto());
        System.out.println("Pulse (3) para comprobar disponibilidad");
    }
    public void stock(){
        System.out.println("Debe teclear el número del producto para saber si hay stock");
    }
    public void pago(){
        System.out.println("Debe de teclear el número del producto antes de proceder al pago");
    }
    public void setMaquina(Maquina maquina){
        this.maquina = maquina;
    }

    
}