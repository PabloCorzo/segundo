public interface State {

    void iniciarMaquina();
    void teclearNumero();
    void stock();
    void pago();
    void setMaquina(Maquina maquina);
}