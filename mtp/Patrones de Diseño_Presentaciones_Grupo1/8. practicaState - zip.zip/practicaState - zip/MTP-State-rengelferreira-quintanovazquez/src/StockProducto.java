public class StockProducto implements State{

    private Maquina maquina;

    public void iniciarMaquina(){
        System.out.println("Máquina ya iniciada");
    }
    public void teclearNumero(){
        System.out.println("Ya seleccionó el producto");
    }
    public void stock(){
        System.out.println("Producto disponible");
        maquina.setState(new Pagar());
        System.out.println("Pulse (4) para proceder al pago");
    }
    public void pago(){
    }
    public void setMaquina(Maquina maquina){
        this.maquina = maquina;
    }
}