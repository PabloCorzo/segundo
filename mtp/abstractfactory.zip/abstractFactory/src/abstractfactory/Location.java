package abstractfactory;

public enum Location {
    DEFAULT, USA, ASIA
}
