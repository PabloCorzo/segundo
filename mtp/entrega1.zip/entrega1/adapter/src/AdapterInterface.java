public interface AdapterInterface {
    void asFile(FormatInterface song);

}