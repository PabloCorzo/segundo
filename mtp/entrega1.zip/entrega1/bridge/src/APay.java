public class APay implements  Pago{
    void pay(){
        System.out.println("pagado por Apple Pay");
    }
}