public class Bizum implements Pago{
    void pay(){
        System.out.println("pagado por bizum");
    }
}