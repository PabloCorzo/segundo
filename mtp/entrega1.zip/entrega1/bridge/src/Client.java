public class Client{
    public static void main(String[] args) {
        Tablet tablet = new Tablet();
        Movil movil = new Movil();
        APay apay = new APay();

    }
}