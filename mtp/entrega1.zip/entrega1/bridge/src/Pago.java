public interface Pago {
    void pay();
}