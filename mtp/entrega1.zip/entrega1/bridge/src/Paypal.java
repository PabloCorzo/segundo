public class Paypal implements  Pago{
    void pay(){
        System.out.println("pagado por paypal");
    }
}