public class Tablet extends Pedido{
    Pedido(int coste,int codigo,String cliente, Pago metodo){
        this.coste = coste;
        this.codigo = codigo;
        this.cliente = cliente;
        this.metodo = metodo
    }
}