package factory;

public class Ordenador {

    private String ram;
    private String disk;
    private String screen;

    public String getRam(){return this.ram;}
    public String getDisk(){return this.disk;}
    public String getScreen(){return this.screen;}

    public void setRam(String ram){this.ram = ram;}
    public void setDisk(String disk){this.disk = disk;}
    public void setScreen(String screen){this.screen = screen;}
}