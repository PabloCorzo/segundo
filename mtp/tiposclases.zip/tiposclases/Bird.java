package tiposclases;

/**
 * Bird
 */
public interface Bird {

    void fly();
    void land();
    
}