package tiposclases;

/**
 * Mammal
 */
public interface Mammal {

    void walk();
    void endWalk();
}